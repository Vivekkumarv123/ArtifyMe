# İnteryer Dizayn Saytı - Interior Design Website
Figma'da olan bu proyekt əsasında hazırlanıb. - Based on the Figma project in the link below.

<a href="https://www.figma.com/file/dcVsgsRaqW43mgZBYGZIjB/Interior-Design-Website-Template-(Community)?node-id=1-5&t=CAcXwSAUPHlTEGMP-0" target="_blank">Figma interior design</a>

<a href="https://interiordesign-website.netlify.app/" target="_blank">Demo File</a> 
